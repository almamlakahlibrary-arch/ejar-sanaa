# قاعدة البيانات - ERD Design
## إيجار صنعاء - Database Architecture

### تصميم قاعدة البيانات القابل للتوسع

---

## الكيانات الأساسية (Core Entities)

### 1. Users (المستخدمون)
```sql
users
├── id (UUID, PK)
├── phone (VARCHAR, UNIQUE, INDEXED)
├── name (VARCHAR)
├── role_id (FK → roles.id)
├── is_verified (BOOLEAN)
├── created_at (TIMESTAMP)
├── updated_at (TIMESTAMP)
└── deleted_at (TIMESTAMP) -- Soft delete
```

### 2. Roles (الأدوار)
```sql
roles
├── id (INT, PK)
├── name (VARCHAR) -- 'user', 'advertiser', 'admin'
└── permissions (JSON)
```

### 3. Properties / Listings (العقارات)
```sql
listings
├── id (UUID, PK)
├── user_id (FK → users.id, INDEXED)
├── property_type_id (FK → property_types.id)
├── title (VARCHAR, INDEXED)
├── description (TEXT)
├── status (ENUM) -- 'active', 'booked', 'paused', 'deleted'
├── is_featured (BOOLEAN)
├── created_at (TIMESTAMP, INDEXED)
├── updated_at (TIMESTAMP)
└── deleted_at (TIMESTAMP) -- Soft delete
```

### 4. Property Types (أنواع العقارات)
```sql
property_types
├── id (INT, PK)
├── code (VARCHAR, UNIQUE) -- 'apartment', 'villa', etc.
├── name_ar (VARCHAR)
├── name_en (VARCHAR)
└── icon (VARCHAR)
```

### 5. Property Attributes (الخصائص الديناميكية)
```sql
property_attributes
├── id (UUID, PK)
├── listing_id (FK → listings.id, INDEXED)
├── attribute_key (VARCHAR) -- 'room_count', 'water_source', etc.
├── attribute_value (JSON) -- Flexible value storage
└── INDEX (listing_id, attribute_key)
```

**مثال على البيانات:**
```json
{
  "room_count": 3,
  "bathroom_count": 2,
  "water_source": "government",
  "water_independence": "independent",
  "electricity_type": "commercial",
  "sunlight_direction": "south",
  "price": 50000,
  "currency": "ريال يمني",
  "price_includes_utilities": false
}
```

### 6. Locations (المواقع)
```sql
locations
├── id (UUID, PK)
├── listing_id (FK → listings.id, INDEXED)
├── district_id (FK → districts.id, INDEXED)
├── neighborhood_id (FK → neighborhoods.id)
├── street (VARCHAR)
├── description (TEXT)
├── latitude (DECIMAL)
├── longitude (DECIMAL)
└── INDEX (district_id, neighborhood_id)
```

### 7. Districts (المديريات)
```sql
districts
├── id (INT, PK)
├── code (VARCHAR, UNIQUE) -- 'sabaeen', 'maeen', etc.
├── name_ar (VARCHAR)
├── name_en (VARCHAR)
└── city_id (FK → cities.id) -- For future expansion
```

### 8. Neighborhoods (الأحياء)
```sql
neighborhoods
├── id (INT, PK)
├── district_id (FK → districts.id, INDEXED)
├── name_ar (VARCHAR)
├── name_en (VARCHAR)
└── INDEX (district_id)
```

### 9. Media (الصور والفيديو)
```sql
media
├── id (UUID, PK)
├── listing_id (FK → listings.id, INDEXED)
├── file_url (VARCHAR)
├── file_type (ENUM) -- 'image', 'video'
├── display_order (INT)
├── created_at (TIMESTAMP)
└── INDEX (listing_id, display_order)
```

### 10. Favorites (المفضلة)
```sql
favorites
├── id (UUID, PK)
├── user_id (FK → users.id, INDEXED)
├── listing_id (FK → listings.id, INDEXED)
├── created_at (TIMESTAMP)
└── UNIQUE (user_id, listing_id)
```

### 11. Reports (الإبلاغات)
```sql
reports
├── id (UUID, PK)
├── listing_id (FK → listings.id)
├── reporter_id (FK → users.id)
├── reason (ENUM) -- 'fake', 'spam', 'inappropriate', etc.
├── description (TEXT)
├── status (ENUM) -- 'pending', 'reviewed', 'resolved'
├── created_at (TIMESTAMP)
└── INDEX (status, created_at)
```

### 12. Sessions (الجلسات)
```sql
sessions
├── id (UUID, PK)
├── user_id (FK → users.id, INDEXED)
├── device_id (VARCHAR)
├── ip_address (VARCHAR)
├── expires_at (TIMESTAMP)
├── created_at (TIMESTAMP)
└── INDEX (user_id, expires_at)
```

---

## استراتيجية الفهرسة (Indexing Strategy)

### فهارس الأداء الحرجة:
1. **listings**: `(status, created_at DESC)` - للبحث السريع
2. **listings**: `(property_type_id, status)` - فلترة حسب النوع
3. **locations**: `(district_id, neighborhood_id)` - البحث الجغرافي
4. **property_attributes**: `(listing_id, attribute_key)` - البحث في الخصائص
5. **users**: `(phone)` - تسجيل الدخول السريع

---

## قرارات التصميم

### 1. Soft Delete
- جميع الكيانات الرئيسية تستخدم `deleted_at` بدلاً من الحذف الفعلي
- يسمح بالاسترجاع والتدقيق

### 2. JSON Attributes
- `property_attributes` يستخدم JSON للسماح بخصائص ديناميكية
- يسهل إضافة أنواع عقارات جديدة بدون تغيير Schema

### 3. Normalization vs Denormalization
- المواقع منفصلة (Normalized) للبحث الجغرافي
- الخصائص في JSON (Denormalized) للأداء

### 4. Future Expansion
- `cities` table جاهز للتوسع لمدن أخرى
- `districts.city_id` يربط المديريات بالمدن

---

## العلاقات (Relationships)

```
users ──┬── listings
        ├── favorites
        ├── reports
        └── sessions

listings ──┬── property_attributes
           ├── locations
           ├── media
           ├── favorites
           └── reports

districts ──┬── neighborhoods
            └── locations

property_types ─── listings
```

---

## Migration Strategy

### Phase 1: MVP
- Users, Roles, Listings, Property Types
- Basic Locations (Districts only)
- Media (Images)

### Phase 2: V1.5
- Property Attributes (JSON)
- Neighborhoods
- Favorites

### Phase 3: V2
- Reports & Moderation
- Advanced Search Indexes
- Analytics Tables

---

## Performance Considerations

1. **Partitioning**: `listings` يمكن تقسيمها حسب `created_at` (Monthly)
2. **Caching**: Redis للبحث الشائع
3. **Full-Text Search**: PostgreSQL Full-Text أو Elasticsearch للبحث النصي
4. **CDN**: للصور والوسائط
