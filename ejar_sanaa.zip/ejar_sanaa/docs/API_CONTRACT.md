# REST API Contract
## إيجار صنعاء - API Documentation

### Base URL
```
Production: https://api.ejarsanaa.com/v1
Staging: https://api-staging.ejarsanaa.com/v1
```

### Authentication
- **Method**: OTP via SMS
- **Header**: `Authorization: Bearer {token}`
- **Token Expiry**: 30 days

---

## Endpoints

### Authentication

#### POST `/auth/send-otp`
Send OTP to phone number.

**Request:**
```json
{
  "phone": "+967712345678"
}
```

**Response:**
```json
{
  "success": true,
  "message": "OTP sent",
  "data": {
    "session_id": "uuid",
    "expires_in": 300
  }
}
```

#### POST `/auth/verify-otp`
Verify OTP and get access token.

**Request:**
```json
{
  "session_id": "uuid",
  "otp": "123456"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "token": "jwt_token",
    "user": {
      "id": "uuid",
      "phone": "+967712345678",
      "name": null,
      "role": "user"
    }
  }
}
```

---

### User Profile

#### GET `/user/profile`
Get current user profile.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "phone": "+967712345678",
    "name": "أحمد محمد",
    "role": "advertiser",
    "is_verified": true,
    "created_at": "2024-01-01T00:00:00Z"
  }
}
```

#### PUT `/user/profile`
Update user profile.

**Request:**
```json
{
  "name": "أحمد محمد"
}
```

---

### Listings (CRUD)

#### GET `/listings`
Search and filter listings.

**Query Parameters:**
- `page` (int, default: 1)
- `limit` (int, default: 20, max: 100)
- `type` (string) - Property type code
- `district` (string) - District code
- `min_price` (int)
- `max_price` (int)
- `min_rooms` (int)
- `water_independence` (string) - 'independent' | 'shared'
- `electricity_independence` (string) - 'independent' | 'shared'
- `sunlight_direction` (string) - 'south' | 'east' | 'west' | 'north'
- `negotiable` (boolean)
- `search` (string) - Free text search
- `sort` (string) - 'newest' | 'price_asc' | 'price_desc'

**Response:**
```json
{
  "success": true,
  "data": {
    "listings": [
      {
        "id": "uuid",
        "type": "apartment",
        "title": "شقة للايجار في السبعين",
        "price": 50000,
        "currency": "ريال يمني",
        "district": "السبعين",
        "neighborhood": "الأصبحي",
        "room_count": 3,
        "bathroom_count": 2,
        "has_external_majlis": true,
        "sunlight_direction": "south",
        "water_source": "government",
        "electricity_type": "commercial",
        "images": ["url1", "url2"],
        "created_at": "2024-01-01T00:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "total_pages": 8
    }
  }
}
```

#### GET `/listings/:id`
Get single listing details.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "type": "apartment",
    "title": "شقة للايجار في السبعين",
    "description": "...",
    "attributes": {
      "room_count": 3,
      "bathroom_count": 2,
      "floor": "first",
      "water_source": "government",
      "water_independence": "independent",
      "electricity_type": "commercial",
      "electricity_independence": "independent",
      "sunlight_direction": "south",
      "has_external_majlis": true,
      "external_majlis_has_bathroom": true,
      "has_solar_panels": true
    },
    "location": {
      "district": "السبعين",
      "neighborhood": "الأصبحي",
      "street": "شارع الزبيري",
      "description": "قرب مسجد وسوق"
    },
    "financial": {
      "price": 50000,
      "currency": "ريال يمني",
      "price_includes_utilities": false,
      "deposit": 50000,
      "advance": 50000,
      "has_brokerage": false,
      "negotiable": true,
      "requires_guarantee": true,
      "guarantee_type": "تجاري",
      "is_commercial": false
    },
    "contact": {
      "phone": "+967712345678",
      "seller_type": "owner",
      "seller_name": "أحمد محمد"
    },
    "images": ["url1", "url2", "url3"],
    "status": "active",
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
}
```

#### POST `/listings`
Create new listing.

**Request:**
```json
{
  "type": "apartment",
  "title": "شقة للايجار",
  "description": "...",
  "attributes": {
    "room_count": 3,
    "bathroom_count": 2,
    "water_source": "government",
    "electricity_type": "commercial"
  },
  "location": {
    "district_id": 4,
    "neighborhood_id": 12,
    "street": "شارع الزبيري",
    "description": "..."
  },
  "financial": {
    "price": 50000,
    "currency": "ريال يمني",
    "price_includes_utilities": false,
    "negotiable": true
  },
  "contact": {
    "phone": "+967712345678",
    "seller_type": "owner",
    "seller_name": "أحمد محمد"
  },
  "images": ["base64_image1", "base64_image2"]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "message": "Listing created successfully"
  }
}
```

#### PUT `/listings/:id`
Update listing.

#### DELETE `/listings/:id`
Delete listing (soft delete).

---

### Favorites

#### GET `/favorites`
Get user's favorite listings.

#### POST `/favorites`
Add listing to favorites.

**Request:**
```json
{
  "listing_id": "uuid"
}
```

#### DELETE `/favorites/:id`
Remove from favorites.

---

### Search & Suggestions

#### GET `/search/suggestions`
Get search suggestions.

**Query Parameters:**
- `q` (string) - Search query

**Response:**
```json
{
  "success": true,
  "data": {
    "districts": ["السبعين", "معين"],
    "neighborhoods": ["الأصبحي", "شملان"],
    "types": ["شقة", "فيلا"]
  }
}
```

---

### Admin Endpoints

#### GET `/admin/listings`
Get all listings with filters (admin only).

#### PUT `/admin/listings/:id/status`
Update listing status.

**Request:**
```json
{
  "status": "active" | "paused" | "deleted"
}
```

#### GET `/admin/reports`
Get reported listings.

#### PUT `/admin/reports/:id/resolve`
Resolve report.

---

## Error Responses

### Standard Error Format
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {}
  }
}
```

### Common Error Codes
- `AUTH_REQUIRED` (401)
- `AUTH_INVALID` (401)
- `NOT_FOUND` (404)
- `VALIDATION_ERROR` (400)
- `RATE_LIMIT_EXCEEDED` (429)
- `SERVER_ERROR` (500)

---

## Rate Limiting

- **Authentication**: 5 requests/minute per IP
- **Listings**: 100 requests/minute per user
- **Search**: 200 requests/minute per IP

---

## Pagination

All list endpoints support pagination:
- `page`: Page number (1-indexed)
- `limit`: Items per page (default: 20, max: 100)

Response includes:
```json
{
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "total_pages": 8,
    "has_next": true,
    "has_prev": false
  }
}
```

---

## Versioning

- Current version: `v1`
- Version in URL: `/v1/...`
- Backward compatibility maintained for at least 6 months
