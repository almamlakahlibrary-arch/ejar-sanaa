import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:ejar_sanaa/core/constants/districts.dart';
import 'package:ejar_sanaa/models/listing_model.dart';
import 'package:ejar_sanaa/providers/listing_provider.dart';

class AddListingScreen extends StatefulWidget {
  const AddListingScreen({super.key});

  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _formKey = GlobalKey<FormBuilderState>();
  int _currentStep = 0;
  bool _isLoading = false;
  final List<XFile> _selectedImages = [];

  final _picker = ImagePicker();

  final List<Map<String, dynamic>> _categories = [
    {'value': 'شقة', 'icon': Icons.apartment},
    {'value': 'عمارة', 'icon': Icons.business},
    {'value': 'فيلا', 'icon': Icons.home},
    {'value': 'محل', 'icon': Icons.store},
    {'value': 'بدروم', 'icon': Icons.layers},
    {'value': 'صالة أعراس', 'icon': Icons.celebration},
    {'value': 'قطعة أرض', 'icon': Icons.terrain},
    {'value': 'حوش', 'icon': Icons.fence},
    {'value': 'سيارة', 'icon': Icons.directions_car},
    {'value': 'دراجة نارية', 'icon': Icons.motorcycle},
    {'value': 'بسطة', 'icon': Icons.storefront},
    {'value': 'أخرى', 'icon': Icons.more_horiz},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة إعلان جديد'),
      ),
      body: FormBuilder(
        key: _formKey,
        child: Stepper(
          currentStep: _currentStep,
          onStepContinue: _onStepContinue,
          onStepCancel: _onStepCancel,
          onStepTapped: (step) {
            if (step <= _currentStep) {
              setState(() => _currentStep = step);
            }
          },
          controlsBuilder: (context, details) {
            return Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : details.onStepContinue,
                      child: _isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(_currentStep == 3 ? 'نشر الإعلان' : 'التالي'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  if (_currentStep > 0)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _isLoading ? null : details.onStepCancel,
                        child: const Text('السابق'),
                      ),
                    ),
                ],
              ),
            );
          },
          steps: [
            Step(
              title: const Text('المعلومات الأساسية'),
              isActive: _currentStep >= 0,
              content: _buildBasicInfoStep(),
            ),
            Step(
              title: const Text('الموقع والتفاصيل'),
              isActive: _currentStep >= 1,
              content: _buildLocationStep(),
            ),
            Step(
              title: const Text('الصور'),
              isActive: _currentStep >= 2,
              content: _buildImagesStep(),
            ),
            Step(
              title: const Text('المراجعة'),
              isActive: _currentStep >= 3,
              content: _buildReviewStep(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBasicInfoStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'اختر نوع العقار',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),

        FormBuilderField<String>(
          name: 'category',
          validator: FormBuilderValidators.required(errorText: 'يرجى اختيار نوع العقار'),
          builder: (field) {
            return Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _categories.map((category) {
                final isSelected = field.value == category['value'];
                return ChoiceChip(
                  label: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(category['icon'], size: 18),
                      const SizedBox(width: 6),
                      Text(category['value']),
                    ],
                  ),
                  selected: isSelected,
                  onSelected: (selected) {
                    field.didChange(selected ? category['value'] : null);
                  },
                );
              }).toList(),
            );
          },
        ),

        const SizedBox(height: 20),

        FormBuilderTextField(
          name: 'title',
          decoration: const InputDecoration(
            labelText: 'عنوان الإعلان',
            hintText: 'مثال: شقة مفروشة للإيجار في حدة',
            prefixIcon: Icon(Icons.title),
          ),
          validator: FormBuilderValidators.compose([
            FormBuilderValidators.required(errorText: 'يرجى إدخال عنوان الإعلان'),
            FormBuilderValidators.minLength(10, errorText: 'العنوان قصير جداً'),
          ]),
        ),

        const SizedBox(height: 16),

        FormBuilderTextField(
          name: 'description',
          decoration: const InputDecoration(
            labelText: 'وصف الإعلان',
            hintText: 'اكتب تفاصيل العقار والمميزات...',
            prefixIcon: Icon(Icons.description),
          ),
          maxLines: 4,
          validator: FormBuilderValidators.compose([
            FormBuilderValidators.required(errorText: 'يرجى إدخال وصف الإعلان'),
            FormBuilderValidators.minLength(30, errorText: 'الوصف قصير جداً'),
          ]),
        ),

        const SizedBox(height: 16),

        FormBuilderTextField(
          name: 'price',
          decoration: const InputDecoration(
            labelText: 'السعر (ريال يمني)',
            hintText: 'مثال: 150000',
            prefixIcon: Icon(Icons.attach_money),
          ),
          keyboardType: TextInputType.number,
          validator: FormBuilderValidators.compose([
            FormBuilderValidators.required(errorText: 'يرجى إدخال السعر'),
            FormBuilderValidators.numeric(errorText: 'يرجى إدخال رقم صحيح'),
            FormBuilderValidators.min(1000, errorText: 'السعر منخفض جداً'),
          ]),
        ),
      ],
    );
  }

  Widget _buildLocationStep() {
    return Column(
      children: [
        FormBuilderDropdown<String>(
          name: 'district',
          decoration: const InputDecoration(
            labelText: 'الحي',
            prefixIcon: Icon(Icons.location_on),
          ),
          items: Districts.sanaaDistricts
              .map((district) => DropdownMenuItem(
                    value: district,
                    child: Text(district),
                  ))
              .toList(),
          validator: FormBuilderValidators.required(errorText: 'يرجى اختيار الحي'),
        ),

        const SizedBox(height: 16),

        FormBuilderTextField(
          name: 'address',
          decoration: const InputDecoration(
            labelText: 'العنوان التفصيلي',
            hintText: 'مثال: شارع الجزائر، بجانب مستشفى...',
            prefixIcon: Icon(Icons.home),
          ),
          validator: FormBuilderValidators.required(errorText: 'يرجى إدخال العنوان'),
        ),

        const SizedBox(height: 20),

        const Text(
          'معلومات إضافية',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),

        Row(
          children: [
            Expanded(
              child: FormBuilderTextField(
                name: 'rooms',
                decoration: const InputDecoration(
                  labelText: 'الغرف',
                  prefixIcon: Icon(Icons.bed),
                ),
                keyboardType: TextInputType.number,
                validator: FormBuilderValidators.numeric(errorText: 'رقم غير صحيح'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FormBuilderTextField(
                name: 'bathrooms',
                decoration: const InputDecoration(
                  labelText: 'الحمامات',
                  prefixIcon: Icon(Icons.bathroom),
                ),
                keyboardType: TextInputType.number,
                validator: FormBuilderValidators.numeric(errorText: 'رقم غير صحيح'),
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),

        Row(
          children: [
            Expanded(
              child: FormBuilderTextField(
                name: 'area',
                decoration: const InputDecoration(
                  labelText: 'المساحة (م²)',
                  prefixIcon: Icon(Icons.square_foot),
                ),
                keyboardType: TextInputType.number,
                validator: FormBuilderValidators.numeric(errorText: 'رقم غير صحيح'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FormBuilderTextField(
                name: 'floor',
                decoration: const InputDecoration(
                  labelText: 'الدور',
                  prefixIcon: Icon(Icons.layers),
                ),
                keyboardType: TextInputType.number,
                validator: FormBuilderValidators.numeric(errorText: 'رقم غير صحيح'),
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),

        FormBuilderSwitch(
          name: 'furnished',
          title: const Text('مفروش'),
          initialValue: false,
        ),

        FormBuilderSwitch(
          name: 'parking',
          title: const Text('موقف سيارات'),
          initialValue: false,
        ),
      ],
    );
  }

  Widget _buildImagesStep() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _pickImages(ImageSource.gallery),
                icon: const Icon(Icons.photo_library),
                label: const Text('اختر من المعرض'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _pickImages(ImageSource.camera),
                icon: const Icon(Icons.camera_alt),
                label: const Text('التقط صورة'),
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),

        if (_selectedImages.isEmpty)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Column(
              children: [
                Icon(Icons.image, size: 48, color: Colors.grey),
                SizedBox(height: 8),
                Text('لم يتم اختيار صور بعد'),
                Text('أضف صور للعقار لزيادة فرص الإيجار',
                    style: TextStyle(color: Colors.grey)),
              ],
            ),
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: _selectedImages.length,
            itemBuilder: (context, index) {
              return Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey.shade200,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        _selectedImages[index].path,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        errorBuilder: (context, error, stackTrace) {
                          return const Center(
                            child: Icon(Icons.broken_image, color: Colors.grey),
                          );
                        },
                      ),
                    ),
                  ),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedImages.removeAt(index);
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

        const SizedBox(height: 8),
        Text(
          'عدد الصور: ${_selectedImages.length}',
          style: const TextStyle(color: Colors.grey),
        ),
      ],
    );
  }

  Widget _buildReviewStep() {
    final formValues = _formKey.currentState?.value ?? {};

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'راجع معلومات الإعلان قبل النشر',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),

        _buildReviewItem('نوع العقار', formValues['category'] ?? ''),
        _buildReviewItem('العنوان', formValues['title'] ?? ''),
        _buildReviewItem('السعر', '${formValues['price'] ?? ''} ريال يمني'),
        _buildReviewItem('الحي', formValues['district'] ?? ''),
        _buildReviewItem('العنوان', formValues['address'] ?? ''),
        _buildReviewItem('عدد الصور', '${_selectedImages.length}'),

        const SizedBox(height: 20),

        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.shade200),
          ),
          child: const Row(
            children: [
              Icon(Icons.info, color: Colors.blue),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'بعد نشر الإعلان، سيتم مراجعته قبل الظهور للآخرين.',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReviewItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(
            child: Text(value.isEmpty ? '-' : value),
          ),
        ],
      ),
    );
  }

  void _onStepContinue() async {
    final isLastStep = _currentStep == 3;

    if (_currentStep < 3) {
      final isValid = _validateCurrentStep();
      if (isValid) {
        setState(() => _currentStep++);
      }
      return;
    }

    if (isLastStep) {
      await _submitListing();
    }
  }

  void _onStepCancel() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
    }
  }

  bool _validateCurrentStep() {
    final formState = _formKey.currentState;
    if (formState == null) return false;

    switch (_currentStep) {
      case 0:
        return formState.fields['category']?.validate() == true &&
            formState.fields['title']?.validate() == true &&
            formState.fields['description']?.validate() == true &&
            formState.fields['price']?.validate() == true;
      case 1:
        return formState.fields['district']?.validate() == true &&
            formState.fields['address']?.validate() == true;
      case 2:
        return true;
      default:
        return true;
    }
  }

  Future<void> _pickImages(ImageSource source) async {
    try {
      if (source == ImageSource.camera) {
        final image = await _picker.pickImage(source: source);
        if (image != null) {
          setState(() {
            _selectedImages.add(image);
          });
        }
      } else {
        final images = await _picker.pickMultiImage();
        setState(() {
          _selectedImages.addAll(images);
        });
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حدث خطأ في اختيار الصور: $e')),
      );
    }
  }

  Future<void> _submitListing() async {
    final formState = _formKey.currentState;
    if (formState == null) return;

    if (!formState.saveAndValidate()) {
      return;
    }

    setState(() => _isLoading = true);

    try {
      final values = formState.value;

      final listing = ListingModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: values['title'],
        description: values['description'],
        category: values['category'],
        district: values['district'],
        address: values['address'],
        price: double.tryParse(values['price'].toString()) ?? 0,
        images: _selectedImages.map((img) => img.path).toList(),
        createdAt: DateTime.now(),
        advertiserName: 'معلن',
        advertiserPhone: '',
        rooms: int.tryParse(values['rooms']?.toString() ?? ''),
        bathrooms: int.tryParse(values['bathrooms']?.toString() ?? ''),
        area: double.tryParse(values['area']?.toString() ?? ''),
        floor: int.tryParse(values['floor']?.toString() ?? ''),
        furnished: values['furnished'] ?? false,
        parking: values['parking'] ?? false,
      );

      await Provider.of<ListingProvider>(context, listen: false).addListing(listing);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم نشر الإعلان بنجاح')),
      );

      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حدث خطأ في نشر الإعلان: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
